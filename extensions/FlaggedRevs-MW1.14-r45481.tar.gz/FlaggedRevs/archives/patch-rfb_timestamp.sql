ALTER TABLE /*$wgDBprefix*/reader_feedback
	ADD rfb_timestamp char(14) NOT NULL default '';
