ALTER TABLE /*$wgDBprefix*/reader_feedback
	ADD rfb_ratings mediumblob NOT NULL;
